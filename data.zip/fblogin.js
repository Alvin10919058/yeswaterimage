var sr;
var uid;
var name;
function fblogin() {
  FB.getLoginStatus(function (response) {
    if (response.status === 'connected') {
		sr = response.authResponse.signedRequest;
		uid = response.authResponse.userID;
      FB.api('/me/permissions', function (response) {
		var perms = response.data[0];
		if(perms.publish_stream==1) 
		{
			isLiked1();
		}
		else {
			FB.login(function(response) {
				if (response.authResponse) {
				sr = response.authResponse.signedRequest;
				uid = response.authResponse.userID;
					FB.api('/me/permissions', function (response) {
						var perms = response.data[0];
						if(perms.publish_stream==1) 
						{
							isLiked1();
						}
					});
				}
					else
						voteclick = false;
			},{scope: 'user_likes, publish_stream'});
			}
		});
		} else if (response.status === 'not_authorized') {
		FB.login(function(response) {
			if (response.authResponse) {
			sr = response.authResponse.signedRequest;
			uid = response.authResponse.userID;
				FB.api('/me/permissions', function (response) {
					var perms = response.data[0];
					if(perms.publish_stream==1) 
					{
						isLiked1();
					}
				});
			}
					else
						voteclick = false;
		},{scope: 'user_likes, publish_stream'});
		} else {
				FB.login(function(response) {
					if (response.authResponse) {
					sr = response.authResponse.signedRequest;
					uid = response.authResponse.userID;
						FB.api('/me/permissions', function (response) {
							var perms = response.data[0];
							if(perms.publish_stream==1) 
							{
								isLiked1();
							}
						});
					}
					else
						voteclick = false;
				},{scope: 'user_likes, publish_stream'});
	  }
	});
}

function fbloginForJoin()
{
  FB.getLoginStatus(function (response) {
    if (response.status === 'connected') {
		sr = response.authResponse.signedRequest;
		uid = response.authResponse.userID;
		
		$("#fbid").val(uid);
		
      FB.api('/me/permissions', function (response) {
		var perms = response.data[0];
		if(perms.publish_stream==1) 
		{
			var obj = document.myForm;
			obj.submit();
		}
		else {
			FB.login(function(response) {
				if (response.authResponse) {
				sr = response.authResponse.signedRequest;
				uid = response.authResponse.userID;
				
			$("#fbid").val(uid);
				
					FB.api('/me/permissions', function (response) {
						var perms = response.data[0];
						if(perms.publish_stream==1) 
						{
							var obj = document.myForm;
							obj.submit();
						}
					});
				}
			},{scope: 'user_likes, publish_stream'});
			}
		});
		} else if (response.status === 'not_authorized') {
		FB.login(function(response) {
			if (response.authResponse) {
			sr = response.authResponse.signedRequest;
			uid = response.authResponse.userID;
			$("#fbid").val(uid);
			
			
				FB.api('/me/permissions', function (response) {
					var perms = response.data[0];
					if(perms.publish_stream==1) 
					{
						var obj = document.myForm;
						obj.submit();
					}
				});
			} 
		},{scope: 'user_likes, publish_stream'});
		} else {
				FB.login(function(response) {
					if (response.authResponse) {
					sr = response.authResponse.signedRequest;
					uid = response.authResponse.userID;
					$("#fbid").val(uid);
						FB.api('/me/permissions', function (response) {
							var perms = response.data[0];
							if(perms.publish_stream==1) 
							{
								var obj = document.myForm;
								obj.submit();
							}
						});
					}
					
					
				},{scope: 'user_likes, publish_stream'});
	  }
	});
}

function isEmpty(obj) {
    for(var prop in obj) {
        if(obj.hasOwnProperty(prop))
            return false;
    }
 
    return true;
}

function isLiked1(){
FB.api('/me/likes/268571563312135',function(response) 
{
    if( response.data ) 
	{
        if( !isEmpty(response.data) )
		{
			like1 = true;
			isLiked2();
		}
        else
		{
			like1 = false;
			$('.like-box').show();
			
			//調整讚的位置(for ff&ie)
			var div = document.getElementById('like-box');
			div.style.position = 'absolute';
			div.style.top = '500px';
		}
    } 
	else 
	{
        alert('ERROR!');
    }
});

}

function isLiked2()
{
FB.api('/me/likes/362988463847309',function(response) {
    if( response.data ) {
        if( !isEmpty(response.data) ){
			like2 = true;
			$('.like-box').hide();
			FB.getLoginStatus(function (response) {
				if (response.status === 'connected') {
					uid = response.authResponse.userID;
				}
			});
			if(loc=="index")
			{
				//抓出fbname之後繼續
				FB.api('/me', function(response) {
					name = response.name;
					$("#fbname").val(name);
					vote();
				});
			}
			else if(loc=="join")
				joinForm();
		}
        else{
			like2 = false;
			$('.like-box').show();
			
			//調整讚的位置(for ff&ie)
			var div = document.getElementById('like-box');
			div.style.position = 'absolute';
			div.style.top = '500px';
		}
    }
	else {
        alert('ERROR!');
    }
});
}
		