function vote(){
	$.ajax({
		type:"GET",
		url:'vote.php',
		data:{sr:sr,target:index,fbname:name,targetname:targetname,ip:myip},
		success:function(msg){
			voteclick = false;
			if(msg.match('002'))
			{
				alert("今日已投票過，請明天再來!每人一天只能投一票!");
				window.location="index.php?page="+page;
				$(".vote-box-btn-img").attr("src","images/herfr-vote-me-btn-02.png");
			}
			else if(msg.match('004')){alert('投票時間已過，感謝您的支持！');}
			else if(msg.match('003')) 
			{ 
				alert("已投票成功了喔!感謝您的支持!");
				$(".vote-box-btn-img").attr("src","images/herfr-vote-me-btn-02.png");
				var url = "http://youngfb.com/wiup/images/fb_share_img.jpg";
				var result;
				result="『超能量wi-up強力徵求日本血拚達人，快將購物的戰利品照片上傳至活動網站，就有機會得到SAMSUNG NX MINI 9-27相機，投票還可抽FUJIFILM XP60相機喔!!』";
	
				var body = result;
				FB.getLoginStatus(function (response) {
				if(response.status === 'connected')
				{
					/*FB.api('/me/feed/', 'post', { message: body,link: 'http://youngfb.com/wiup/index.php?page='+page ,picture: url,name: 'wi-up 日本戰利品PK讚' }, function(response) {
					if (!response || response.error) {
						alert(response.error.message);
						alert('Error occured');
					} 
					else 
					{*/
						location.reload();
					//}});	
				}

				});
			}
			else if(msg.match('005'))
			{
				alert("投票無效，請稍候再試");
				location.reload();
			}
		}
	});
}